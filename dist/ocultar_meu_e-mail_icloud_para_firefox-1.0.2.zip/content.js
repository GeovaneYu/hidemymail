// content.js - Apple Hide My Email style
let lastFocusedEmailInput = null;
let autofillButton = null;

function isEmailInput(el) {
  if (!el || el.tagName !== 'INPUT') return false;
  const type = (el.type || '').toLowerCase();
  const name = (el.name || '').toLowerCase();
  const id = (el.id || '').toLowerCase();
  const placeholder = (el.placeholder || '').toLowerCase();
  const autocomplete = (el.autocomplete || '').toLowerCase();
  return type === 'email' || autocomplete === 'email' || name.includes('email') || id.includes('email') || placeholder.includes('email') || placeholder.includes('e-mail');
}

function createButton() {
  const btn = document.createElement('button');
  btn.textContent = ' Ocultar Meu E-mail';
  btn.className = 'hidemymail-autofill-btn';
  btn.type = 'button';
  btn.addEventListener('mousedown', (e) => {
    e.preventDefault();
    if (lastFocusedEmailInput) autofillFromBackground(lastFocusedEmailInput);
  });
  return btn;
}

function positionButton(input) {
  if (!autofillButton) return;
  const rect = input.getBoundingClientRect();
  autofillButton.style.top = `${window.scrollY + rect.top - 34}px`;
  autofillButton.style.left = `${window.scrollX + rect.left}px`;
}

function showButtonFor(input) {
  lastFocusedEmailInput = input;
  if (!autofillButton) {
    autofillButton = createButton();
    document.body.appendChild(autofillButton);
  }
  autofillButton.style.display = 'block';
  positionButton(input);
}

function hideButton() {
  if (autofillButton) autofillButton.style.display = 'none';
}

async function autofillFromBackground(input) {
  try {
    hideButton();
    input.placeholder = 'Gerando endereço Apple…';
    const gen = await browser.runtime.sendMessage({ type: 'GENERATE' });
    if (!gen?.hme) throw new Error('Falha ao gerar');
    const label = location.hostname || 'Firefox';
    const reserved = await browser.runtime.sendMessage({ type: 'RESERVE', hme: gen.hme, label });
    const email = reserved.reserved?.hme || gen.hme;
    fillInput(input, email);
  } catch (e) {
    if (lastFocusedEmailInput) lastFocusedEmailInput.placeholder = 'Erro: faça login em iCloud.com';
    console.error('[HideMyEmail]', e);
  }
}

function fillInput(input, value) {
  input.focus();
  input.value = value;
  input.dispatchEvent(new Event('input', { bubbles: true }));
  input.dispatchEvent(new Event('change', { bubbles: true }));
  input.style.boxShadow = '0 0 0 3px rgba(0,122,255,0.3)';
  input.style.borderColor = '#007aff';
  setTimeout(() => { input.style.boxShadow = ''; input.style.borderColor = ''; }, 1400);
  navigator.clipboard.writeText(value).catch(() => {});
}

document.addEventListener('focusin', (e) => {
  const t = e.target;
  if (isEmailInput(t)) showButtonFor(t);
  else setTimeout(() => { if (document.activeElement !== autofillButton) hideButton(); }, 200);
});
document.addEventListener('scroll', () => { if (lastFocusedEmailInput && autofillButton?.style.display==='block') positionButton(lastFocusedEmailInput); }, true);
window.addEventListener('resize', () => { if (lastFocusedEmailInput && autofillButton?.style.display==='block') positionButton(lastFocusedEmailInput); });

browser.runtime.onMessage.addListener((msg) => {
  if (msg.type === 'AUTOFILL' && msg.hme) {
    const input = lastFocusedEmailInput || document.querySelector('input[type="email"], input[name*="email" i], input[id*="email" i]');
    if (input) fillInput(input, msg.hme);
    else navigator.clipboard.writeText(msg.hme).catch(()=>{});
  }
});
