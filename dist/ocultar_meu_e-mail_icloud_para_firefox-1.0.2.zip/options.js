async function init(){
  const sel=document.getElementById('fwd-select'), st=document.getElementById('status'), badge=document.getElementById('badge');
  try{
    const r=await browser.runtime.sendMessage({type:'VALIDATE'});
    if(!r.authenticated){ st.textContent='Desconectado'; badge.textContent='Desconectado'; badge.style.background='#ffebeb'; badge.style.color='#c62828'; sel.innerHTML='<option>Faça login em iCloud.com</option>'; return; }
    st.textContent='Conectado'; badge.textContent='Conectado'; badge.style.background='#e8f5e9'; badge.style.color='#2e7d32';
    const res=await browser.runtime.sendMessage({type:'LIST'});
    const list=res.forwardToEmails||[], cur=res.selectedForwardTo;
    sel.innerHTML=list.map(e=>`<option value="${e}" ${e===cur?'selected':''}>${e}</option>`).join('');
    sel.onchange=async()=>{
      try{ await browser.runtime.sendMessage({type:'UPDATE_FORWARD', email: sel.value}); sel.style.color='#30d158'; setTimeout(()=>sel.style.color='#007aff',800);}catch(e){ alert(String(e.message||e));}
    };
  }catch(e){ st.textContent='Erro: '+String(e.message||e); badge.textContent='Erro'; }
}
init();
