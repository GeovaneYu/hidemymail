// popup.js - Apple Hide My Email style
const $ = (id) => document.getElementById(id);

let pendingHme = null;
let currentTabHost = '';
let forwardToEmails = [];
let selectedForwardTo = '';
let allItems = [];

async function init() {
  try {
    const [tab] = await browser.tabs.query({ active: true, currentWindow: true });
    if (tab?.url) {
      try { currentTabHost = new URL(tab.url).hostname; $('label-input').value = currentTabHost; } catch {}
    }
  } catch {}
  // restaura estado retrátil
  try {
    const { meusEnderecosOpen } = await browser.storage.local.get('meusEnderecosOpen');
    if (meusEnderecosOpen === false) $('meus-enderecos-details').removeAttribute('open');
    $('meus-enderecos-details').addEventListener('toggle', async () => {
      await browser.storage.local.set({ meusEnderecosOpen: $('meus-enderecos-details').open });
    });
    // evita toggle ao clicar em Atualizar
    $('btn-refresh').addEventListener('click', (e) => { e.preventDefault(); e.stopPropagation(); loadList(); });
  } catch {}
  await checkAuth();
}

async function checkAuth() {
  $('loading').classList.remove('hidden');
  $('signed-in').classList.add('hidden');
  $('signed-out').classList.add('hidden');
  $('status-dot').className = 'status-dot';
  try {
    const res = await browser.runtime.sendMessage({ type: 'VALIDATE' });
    $('loading').classList.add('hidden');
    if (res.authenticated) {
      $('status-dot').className = 'status-dot ok';
      $('signed-in').classList.remove('hidden');
      await loadForwardTo(); // carrega picker antes da lista
      loadList();
    } else {
      $('status-dot').className = 'status-dot err';
      $('signed-out').classList.remove('hidden');
    }
  } catch (e) {
    $('loading').classList.add('hidden');
    $('status-dot').className = 'status-dot err';
    $('signed-out').classList.remove('hidden');
  }
}

async function loadForwardTo() {
  const sel = $('forward-select');
  try {
    const result = await browser.runtime.sendMessage({ type: 'LIST' });
    forwardToEmails = result.forwardToEmails || [];
    selectedForwardTo = result.selectedForwardTo || forwardToEmails[0] || '';
    if (!forwardToEmails.length) {
      sel.innerHTML = `<option>Sem e-mail</option>`;
      return;
    }
    sel.innerHTML = forwardToEmails.map(e => `<option value="${escapeHtml(e)}" ${e===selectedForwardTo?'selected':''}>${escapeHtml(e)}</option>`).join('');
    // se usuário trocar, já atualiza no iCloud
    sel.onchange = async () => {
      const newVal = sel.value;
      if (newVal === selectedForwardTo) return;
      const old = selectedForwardTo;
      selectedForwardTo = newVal;
      try {
        await browser.runtime.sendMessage({ type: 'UPDATE_FORWARD', email: newVal });
        showTransientSuccess(sel, '✓');
      } catch (e) {
        selectedForwardTo = old;
        sel.value = old;
        showError(String(e.message||e));
      }
    };
  } catch (e) {
    sel.innerHTML = `<option>Erro ao carregar</option>`;
  }
}

function showTransientSuccess(el, text) {
  const prev = el.style.color;
  el.style.color = '#30d158';
  setTimeout(() => el.style.color = prev, 800);
}

function showError(msg) {
  const el = $('gen-error');
  el.textContent = msg;
  el.classList.remove('hidden');
  setTimeout(() => el.classList.add('hidden'), 4000);
}

// --- Geração ---
$('btn-generate').addEventListener('click', handleGenerate);
$('btn-refresh-email').addEventListener('click', handleGenerate);
$('btn-generate-again').addEventListener('click', handleGenerate);

async function handleGenerate() {
  const btn = $('btn-generate');
  const prevText = btn.textContent;
  $('gen-error').classList.add('hidden');
  btn.textContent = 'Gerando…';
  btn.disabled = true;
  try {
    const { hme } = await browser.runtime.sendMessage({ type: 'GENERATE' });
    pendingHme = hme;
    // mostra preview Apple
    $('generated-email').textContent = hme;
    $('email-preview-row').classList.remove('hidden');
    $('email-empty').classList.add('hidden');
    $('action-generate').classList.add('hidden');
    $('action-pending').classList.remove('hidden');
    $('action-reserve').classList.add('hidden');
  } catch (e) {
    showError(String(e.message||e));
  } finally {
    btn.textContent = prevText;
    btn.disabled = false;
  }
}

$('btn-validate').addEventListener('click', checkAuth);

// --- Reservar (Criar e usar) ---
$('btn-reserve').addEventListener('click', async () => {
  if (!pendingHme) return;
  const label = $('label-input').value.trim() || currentTabHost || 'Firefox';
  const note = $('note-input').value.trim() || undefined;
  const forwardSel = $('forward-select').value;

  // se trocou forwardTo, garante que está atualizado antes de reservar
  if (forwardSel !== selectedForwardTo) {
    try { await browser.runtime.sendMessage({ type: 'UPDATE_FORWARD', email: forwardSel }); selectedForwardTo = forwardSel; } catch (e) { showError(String(e.message||e)); return; }
  }

  $('btn-reserve').textContent = 'Criando…';
  $('btn-reserve').disabled = true;
  try {
    const { reserved } = await browser.runtime.sendMessage({ type: 'RESERVE', hme: pendingHme, label, note });
    // sucesso Apple
    $('generated-email').textContent = reserved.hme;
    await navigator.clipboard.writeText(reserved.hme).catch(()=>{});
    browser.runtime.sendMessage({ type: 'AUTOFILL_REQUEST', hme: reserved.hme }).catch(()=>{});
    $('action-pending').classList.add('hidden');
    $('action-reserve').classList.remove('hidden');
    pendingHme = null; // limpa para não re-reservar
    loadList();
  } catch (e) {
    showError(String(e.message||e));
    $('btn-reserve').textContent = 'Criar e usar endereço';
    $('btn-reserve').disabled = false;
  } finally {
    $('btn-reserve').disabled = false;
    $('btn-reserve').textContent = 'Criar e usar endereço';
  }
});

$('btn-copy').addEventListener('click', async () => {
  const t = $('generated-email').textContent;
  if (t && t!=='—') await navigator.clipboard.writeText(t);
  $('btn-copy').textContent = '✓ Copiado';
  setTimeout(()=> $('btn-copy').textContent='Copiar', 1200);
});
$('btn-autofill').addEventListener('click', () => {
  const t = $('generated-email').textContent;
  if (t && t!=='—') browser.runtime.sendMessage({ type: 'AUTOFILL_REQUEST', hme: t });
  window.close();
});

// --- Lista ---
$('btn-refresh').addEventListener('click', loadList);
$('search').addEventListener('input', () => renderList(allItems));

async function loadList() {
  const list = $('list');
  list.innerHTML = `<div class="apple-item"><span style="color:#86868b;font-size:12px;">Carregando…</span></div>`;
  $('list-error').classList.add('hidden');
  $('list-empty').classList.add('hidden');
  try {
    const result = await browser.runtime.sendMessage({ type: 'LIST' });
    allItems = result.hmeEmails || [];
    // atualiza também forwardTo caso tenha mudado
    if (result.forwardToEmails) {
      forwardToEmails = result.forwardToEmails;
      selectedForwardTo = result.selectedForwardTo;
      const sel = $('forward-select');
      sel.innerHTML = forwardToEmails.map(e => `<option value="${escapeHtml(e)}" ${e===selectedForwardTo?'selected':''}>${escapeHtml(e)}</option>`).join('');
    }
    allItems.sort((a,b) => b.createTimestamp - a.createTimestamp);
    renderList(allItems);
  } catch (e) {
    list.innerHTML = '';
    $('list-error').textContent = String(e.message||e);
    $('list-error').classList.remove('hidden');
  }
}

function renderList(items) {
  const q = $('search').value.toLowerCase().trim();
  const filtered = q ? items.filter(i => (`${i.hme} ${i.label} ${i.note} ${i.forwardToEmail}`.toLowerCase().includes(q))) : items;
  const list = $('list');
  if (!filtered.length) {
    if (!items.length) { list.innerHTML=''; $('list-empty').classList.remove('hidden'); return; }
    list.innerHTML = `<div class="apple-item"><span style="color:#86868b;font-size:12px;">Nenhum resultado</span></div>`; return;
  }
  $('list-empty').classList.add('hidden');
  list.innerHTML = filtered.map(i => `
    <div class="apple-item ${i.isActive?'active':''} ${i.isActive?'':'inactive'}">
      <div class="item-icon">${i.isActive?'◉':'○'}</div>
      <div class="item-meta">
        <div class="item-hme">${escapeHtml(i.hme)}</div>
        <div class="item-label">${escapeHtml(i.label||'(sem rótulo)')} ${i.note? '· '+escapeHtml(i.note):''}</div>
      </div>
      <span class="item-badge ${i.isActive?'':'off'}">${i.isActive?'Ativo':'Desativado'}</span>
      <div class="item-actions">
        <button data-copy="${escapeHtml(i.hme)}" title="Copiar">⧉</button>
        <button data-autofill="${escapeHtml(i.hme)}" title="Usar">↗</button>
        <button data-toggle="${escapeHtml(i.anonymousId)}" data-active="${i.isActive}" title="${i.isActive?'Desativar':'Reativar'}">${i.isActive?'⏸':'▶︎'}</button>
        <button data-delete="${escapeHtml(i.anonymousId)}" class="danger" title="Apagar">✕</button>
      </div>
    </div>
  `).join('');

  list.querySelectorAll('[data-copy]').forEach(b => b.addEventListener('click', async () => {
    await navigator.clipboard.writeText(b.dataset.copy);
    const o=b.textContent; b.textContent='✓'; setTimeout(()=>b.textContent=o,800);
  }));
  list.querySelectorAll('[data-autofill]').forEach(b => b.addEventListener('click', () => {
    browser.runtime.sendMessage({ type: 'AUTOFILL_REQUEST', hme: b.dataset.autofill });
    window.close();
  }));
  list.querySelectorAll('[data-toggle]').forEach(b => b.addEventListener('click', async () => {
    const id=b.dataset.toggle; const active=b.dataset.active==='true';
    b.disabled=true;
    try { await browser.runtime.sendMessage({ type: active?'DEACTIVATE':'REACTIVATE', anonymousId:id }); loadList(); } catch(e){ alert(String(e.message||e)); b.disabled=false; }
  }));
  list.querySelectorAll('[data-delete]').forEach(b => b.addEventListener('click', async () => {
    if(!confirm('Apagar este endereço? E-mails futuros serão perdidos e não podem ser recuperados.')) return;
    b.disabled=true;
    try { await browser.runtime.sendMessage({ type:'DELETE', anonymousId:b.dataset.delete }); loadList(); } catch(e){ alert(String(e.message||e)); b.disabled=false; }
  }));
}

function escapeHtml(s){ return String(s).replace(/[&<>"']/g, m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m])); }

$('btn-signout').addEventListener('click', async ()=>{ await browser.runtime.sendMessage({type:'SIGN_OUT'}); checkAuth(); });

init();
