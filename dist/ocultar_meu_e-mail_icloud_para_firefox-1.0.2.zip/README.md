# Ocultar Meu E-mail — iCloud+ para Firefox

Visual **idêntico ao iCloud** da Apple — SF Pro, grouped inset, blur, cards arredondados.

Gere aliases do **iCloud+ Hide My Email** direto no Firefox, escolhendo **encaminhamento, rótulo (site) e nota** antes de reservar.

> Inspirado no [dedoussis/icloud-hide-my-email-browser-extension](https://github.com/dedoussis/icloud-hide-my-email-browser-extension) (MIT). Não afiliado à Apple.

## ✨ O que mudou na v1.0 (produção)

- **Visual Apple** 100%: header translúcido, grouped tables, SF Mono para e-mails, badges, search inset, footer Apple.
- **Fluxo completo antes de reservar:**
  1. `Gerar novo endereço` → preview grande com domínio `privaterelay.appleid.com`
  2. Edite **Encaminhar para** (dropdown com todos `forwardToEmails` da conta — atualiza via `updateForwardTo` na hora)
  3. Edite **Rótulo** (auto-preenchido com `location.hostname` da aba ativa) e **Nota** (opcional)
  4. `Criar e usar endereço` → reserva e já **copia + autofill** no site
- **Gerenciar:** lista Apple com ícone, badge Ativo/Desativado, busca, copiar/usar/desativar/reativar/apagar.
- **Produção:** `manifest 1.0.0`, `data_collection_permissions: none`, `web-ext build` validado (0 errors), zip em `dist/`.

## Instalação

### Temporária (dev - já testada)
1. `about:debugging#/runtime/this-firefox` → Load Temporary Add-on → selecione `manifest.json`
2. Faça login em https://icloud.com → 2FA → **Confiar neste navegador**

### Produção (AMO)
```bash
npx web-ext build --source-dir . --artifacts-dir dist
# zip: dist/ocultar_meu_e-mail_icloud_para_firefox-1.0.0.zip
```
Envie em https://addons.mozilla.org/developers/addon/submit/

## Uso

- **Popup:** `Gerar novo endereço` → ajuste Encaminhar/Rótulo/Nota → `Criar e usar endereço`
- **Campo de e-mail:** foque → botão azul ` Ocultar Meu E-mail` flutuante → gera+reserva+preenche
- **Context menu:** clique direito em campo → `Gerar Hide My Email`

## Estrutura

```
manifest.json  # 1.0.0, gecko 113+, DNR
rules.json     # Origin/Referer para icloud.com
background.js  # ICloudClient + PremiumMailSettings (validate, generate, reserve, list, deactivate, reactivate, delete, updateForwardTo)
popup.html/js/css # Apple grouped inset + forward picker
content.js/css # botão Apple
options.html/js   # picker de encaminhamento
icons/         # Apple mail style
dist/          # zip produção
```

## Requisitos

- iCloud+ ativo, Firefox 113+
- Manter sessão em `icloud.com` com `Manter sessão iniciada`
