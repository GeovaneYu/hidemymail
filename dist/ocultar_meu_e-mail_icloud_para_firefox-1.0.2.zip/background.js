// background.js - Firefox MV3 (compatível com MV2 via scripts)
// Lógica baseada em dedoussis/icloud-hide-my-email-browser-extension - MIT

const DEFAULT_SETUP_URL = 'https://setup.icloud.com/setup/ws/1';
const CN_SETUP_URL = 'https://setup.icloud.com.cn/setup/ws/1';
const CONTEXT_MENU_ID = 'hidemymail-generate';

// ---------- ICloudClient ----------
class ICloudClient {
  constructor(setupUrl, webservices) {
    this.setupUrl = setupUrl;
    this.webservices = webservices;
  }

  async request(method, url, { headers = {}, data } = {}) {
    const response = await fetch(url, {
      method,
      headers,
      body: data !== undefined ? JSON.stringify(data) : undefined,
      credentials: 'include',
    });
    if (!response.ok) {
      throw new Error(`Request ${method} ${url} failed: ${response.status}`);
    }
    return response.json();
  }

  webserviceUrl(serviceName) {
    if (!this.webservices) throw new Error('webservices não inicializado - faça validate() primeiro');
    return this.webservices[serviceName].url;
  }

  async isAuthenticated() {
    try {
      await this.validateToken();
      return true;
    } catch { return false; }
  }

  async validateToken() {
    const { webservices } = await this.request('POST', `${this.setupUrl}/validate`);
    if (webservices) this.webservices = webservices;
  }

  async signOut({ trust = false } = {}) {
    await this.request('POST', `${this.setupUrl}/logout`, {
      data: { trustBrowsers: trust, allBrowsers: trust }
    }).catch(() => {});
  }
}

class PremiumMailSettings {
  constructor(client) {
    this.client = client;
    this.baseUrl = `${client.webserviceUrl('premiummailsettings')}/v1`;
    this.v2BaseUrl = `${client.webserviceUrl('premiummailsettings')}/v2`;
  }

  async listHme() {
    const { result } = await this.client.request('GET', `${this.v2BaseUrl}/hme/list`);
    return result;
  }

  async generateHme() {
    const resp = await this.client.request('POST', `${this.baseUrl}/hme/generate`);
    if (!resp.success) throw new Error(resp.error?.errorMessage || 'Falha ao gerar HME');
    return resp.result.hme;
  }

  async reserveHme(hme, label, note = 'Gerado via Hide My Email Firefox') {
    const resp = await this.client.request('POST', `${this.baseUrl}/hme/reserve`, {
      data: { hme, label, note }
    });
    if (!resp.success) throw new Error(resp.error?.errorMessage || 'Falha ao reservar HME');
    return resp.result.hme;
  }

  async deactivateHme(anonymousId) {
    const resp = await this.client.request('POST', `${this.baseUrl}/hme/deactivate`, { data: { anonymousId } });
    if (!resp.success) throw new Error('Falha ao desativar');
  }
  async reactivateHme(anonymousId) {
    const resp = await this.client.request('POST', `${this.baseUrl}/hme/reactivate`, { data: { anonymousId } });
    if (!resp.success) throw new Error('Falha ao reativar');
  }
  async deleteHme(anonymousId) {
    const resp = await this.client.request('POST', `${this.baseUrl}/hme/delete`, { data: { anonymousId } });
    if (!resp.success) throw new Error('Falha ao deletar');
  }
  async updateForwardTo(email) {
    const resp = await this.client.request('POST', `${this.baseUrl}/hme/updateForwardTo`, { data: { forwardToEmail: email } });
    if (!resp.success) throw new Error('Falha ao atualizar forwardTo');
  }
}

// ---------- Storage helpers ----------
async function getStorage(key) {
  const r = await browser.storage.local.get(key);
  return r[key];
}
async function setStorage(key, value) {
  if (value === undefined) await browser.storage.local.remove(key);
  else await browser.storage.local.set({ [key]: value });
}

async function getClient() {
  const clientState = await getStorage('clientState');
  if (!clientState) return new ICloudClient(DEFAULT_SETUP_URL);
  return new ICloudClient(clientState.setupUrl, clientState.webservices);
}

async function saveClientState(client) {
  await setStorage('clientState', { setupUrl: client.setupUrl, webservices: client.webservices });
}

// ---------- Context Menu ----------
async function setupContextMenu() {
  try { await browser.contextMenus.remove(CONTEXT_MENU_ID); } catch {}
  browser.contextMenus.create({
    id: CONTEXT_MENU_ID,
    title: 'Gerar Hide My Email',
    contexts: ['editable'],
    enabled: false,
  });
  // tenta validar auth em background
  const client = await getClient();
  const ok = await client.isAuthenticated();
  if (ok) {
    await saveClientState(client);
    browser.contextMenus.update(CONTEXT_MENU_ID, { enabled: true }).catch(() => {});
  }
}

browser.runtime.onInstalled.addListener(setupContextMenu);
browser.runtime.onStartup?.addListener(setupContextMenu);
// Firefox não persiste contextMenus após restart, então garante na carga
setupContextMenu();

browser.contextMenus.onClicked.addListener(async (info, tab) => {
  if (info.menuItemId !== CONTEXT_MENU_ID) return;
  try {
    const clientState = await getStorage('clientState');
    if (!clientState) throw new Error('Não autenticado - faça login em icloud.com');
    const client = new ICloudClient(clientState.setupUrl, clientState.webservices);
    if (!await client.isAuthenticated()) throw new Error('Sessão expirada - faça login novamente em icloud.com');
    const pms = new PremiumMailSettings(client);
    const hme = await pms.generateHme();
    // tenta reservar com hostname da aba
    let label = 'Firefox';
    try { if (tab?.url) label = new URL(tab.url).hostname; } catch {}
    const reserved = await pms.reserveHme(hme, label);
    if (tab?.id) {
      browser.tabs.sendMessage(tab.id, { type: 'AUTOFILL', hme: reserved.hme }).catch(() => {});
      // fallback: copy via notification
      browser.notifications?.create({
        type: 'basic',
        iconUrl: 'icons/icon-128.png',
        title: 'Hide My Email',
        message: `${reserved.hme} copiado - colado no campo`
      }).catch(() => {});
    }
  } catch (e) {
    browser.notifications?.create({
      type: 'basic',
      iconUrl: 'icons/icon-128.png',
      title: 'Hide My Email - erro',
      message: String(e.message || e)
    }).catch(() => {});
  }
});

// ---------- Message handling (popup <-> background <-> content) ----------
browser.runtime.onMessage.addListener(async (msg, sender) => {
  // Usado pelo popup
  if (msg.type === 'VALIDATE') {
    const client = await getClient();
    const ok = await client.isAuthenticated();
    if (ok) await saveClientState(client);
    else await setStorage('clientState', undefined);
    return { authenticated: ok, setupUrl: client.setupUrl };
  }
  if (msg.type === 'SIGN_OUT') {
    const client = await getClient();
    await client.signOut();
    await setStorage('clientState', undefined);
    browser.contextMenus.update(CONTEXT_MENU_ID, { enabled: false }).catch(() => {});
    return { ok: true };
  }
  if (msg.type === 'GENERATE') {
    const clientState = await getStorage('clientState');
    if (!clientState) throw new Error('Não autenticado');
    const client = new ICloudClient(clientState.setupUrl, clientState.webservices);
    if (!await client.isAuthenticated()) {
      await setStorage('clientState', undefined);
      throw new Error('Sessão expirada');
    }
    await saveClientState(client);
    const pms = new PremiumMailSettings(client);
    const hme = await pms.generateHme();
    return { hme };
  }
  if (msg.type === 'RESERVE') {
    const { hme, label, note } = msg;
    const client = await getClient();
    const pms = new PremiumMailSettings(client);
    const reserved = await pms.reserveHme(hme, label, note);
    return { reserved };
  }
  if (msg.type === 'LIST') {
    const client = await getClient();
    const pms = new PremiumMailSettings(client);
    const result = await pms.listHme();
    await saveClientState(client);
    return result;
  }
  if (msg.type === 'DEACTIVATE') {
    const client = await getClient();
    const pms = new PremiumMailSettings(client);
    await pms.deactivateHme(msg.anonymousId);
    return { ok: true };
  }
  if (msg.type === 'REACTIVATE') {
    const client = await getClient();
    const pms = new PremiumMailSettings(client);
    await pms.reactivateHme(msg.anonymousId);
    return { ok: true };
  }
  if (msg.type === 'DELETE') {
    const client = await getClient();
    const pms = new PremiumMailSettings(client);
    await pms.deleteHme(msg.anonymousId);
    return { ok: true };
  }
  if (msg.type === 'UPDATE_FORWARD') {
    const client = await getClient();
    const pms = new PremiumMailSettings(client);
    await pms.updateForwardTo(msg.email);
    return { ok: true };
  }
  if (msg.type === 'AUTOFILL_REQUEST') {
    // popup pede para autofill na aba ativa
    const [tab] = await browser.tabs.query({ active: true, currentWindow: true });
    if (tab?.id) await browser.tabs.sendMessage(tab.id, { type: 'AUTOFILL', hme: msg.hme });
    return { ok: true };
  }
});
