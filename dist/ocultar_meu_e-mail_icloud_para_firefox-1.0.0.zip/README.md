# Hide My Email — Firefox

Esqueleto minimalista inspirado no [dedoussis/icloud-hide-my-email-browser-extension](https://github.com/dedoussis/icloud-hide-my-email-browser-extension) (MIT).

Gera e gerencia aliases do **iCloud+ Hide My Email** direto no Firefox, sem precisar abrir `icloud.com` manualmente toda vez.

## Como funciona

- Usa os **cookies do `icloud.com`** já logado no Firefox (mesma técnica do projeto original).
- Faz chamadas para `setup.icloud.com/validate` + `pXX-maildomainws.icloud.com/v1/v2/hme/*` com headers `Origin: https://www.icloud.com`.
- Nunca vê sua senha — você loga direto em `icloud.com`.
- `declarativeNetRequest` injeta `Origin/Referer` para simular o site iCloud.

## Instalação (temporária — dev)

1. No Firefox: `about:debugging` → **This Firefox** → **Load Temporary Add-on**
2. Selecione o arquivo `manifest.json` desta pasta (`/Users/geovanegofredo/Documents/geovane/00_inbox/hidemymail`)
3. Faça login em https://icloud.com (complete 2FA e clique em **Confiar neste navegador** + marque **Manter sessão iniciada**)
4. Clique no ícone 🔒 da extensão na barra de ferramentas

> **Requisito:** iCloud+ ativo e Firefox ≥113.

## Uso

- **Popup:** `Gerar novo alias` → `Reservar` (com rótulo = hostname atual). Depois `Copiar` ou `Preencher`.
- **Autofill automático:** Foque em qualquer `<input type="email">` → aparece botão azul “🔒 Hide My Email” acima do campo. Clique para gerar+reservar e preencher.
- **Menu de contexto:** Clique direito em campo editável → `Gerar Hide My Email`.
- **Gerenciar:** Lista no popup mostra todos, com busca, copiar/preencher/desativar/reativar/deletar.

## Estrutura

```
manifest.json   # MV3 + browser_specific_settings.gecko
rules.json      # DNR para Origin/Referer
background.js   # ICloudClient + PremiumMailSettings + contextMenus
popup.html/js/css
content.js/css  # botão flutuante + autofill
options.html/js
icons/
```

## API implementada (em background.js:12)

- `GET/POST` genérico com `credentials: 'include'`
- `POST /validate` → salva `webservices.premiummailsettings`
- `GET /v2/hme/list`, `POST /v1/hme/generate`, `/reserve`, `/deactivate`, `/reactivate`, `/delete`, `/updateForwardTo`

## Limitações vs original

- Sem React/Tailwind/Webpack — vanilla JS para esqueleto simples.
- Sem `userguide.html` completo (ver original).
- Faltando `updateMetaData` (edição de label/nota) — adicione em `background.js` se precisar.

## Build para distribuição (opcional)

Para publicar na AMO, empacote:

```bash
zip -r hidemymail-firefox.zip manifest.json background.js popup.* content.* options.* rules.json icons/
```

Depois envie em https://addons.mozilla.org/developers/

## TODO

- [ ] Editar label/nota de alias existente
- [ ] Suporte a `icloud.com.cn`
- [ ] Testes com Playwright
